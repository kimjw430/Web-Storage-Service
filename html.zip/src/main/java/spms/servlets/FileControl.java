package spms.servlets;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.List;
import java.io.IOException;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.DataFlavor;
import java.util.Objects;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletContext;

import spms.vo.Member;
/**
 * Servlet implementation class Download
 */
@WebServlet("/file_control")
public class FileControl extends HttpServlet
{
	public static void copy(File sourceF, File targetF)
	{
		FileInputStream fis = null;
		FileOutputStream fos = null;
		try {
			fis = new FileInputStream(sourceF);
			fos = new FileOutputStream(targetF) ;
			byte[] b = new byte[4096];
			int cnt = 0;
			while((cnt=fis.read(b)) != -1){
				fos.write(b, 0, cnt);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			try {
				fis.close();
				fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

	public static void copyDir(File sourceF, File targetF){
		File[] ff = sourceF.listFiles();
		for (File file : ff) {
			File temp = new File(targetF.getAbsolutePath() + File.separator + file.getName());
			if(file.isDirectory()){
				temp.mkdir();
				copyDir(file, temp);
			} else {
				copy(file, temp);
			}
		}
	}

	public static boolean deleteDirectory(File path) {
		if(!path.exists()) {
			return false;
		}
		 
		File[] files = path.listFiles();
		for (File file : files) {
			if (file.isDirectory()) {
				deleteDirectory(file);
			} else {
				file.delete();
			}
		}
		 
		return path.delete();
	}

	private static final long serialVersionUID = 1L;
  
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{
		//doPost(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{
		String rootPath_in_url = "/fileUpload";

		HttpSession session = request.getSession();
		Member member = (Member)session.getAttribute("member");
		ServletContext context = getServletContext();
		if(!Objects.isNull(member)){
			if(!member.getEmail().equals("admin"))
				rootPath_in_url = "/fileUpload/" + member.getEmail();
		}

		String rootPath = context.getRealPath(rootPath_in_url);

		//�Է°� �˻� ����
		if(!context.getRealPath(rootPath_in_url + request.getParameter("path")).contains(rootPath))
		{
			response.getWriter().write("Wrong Directory access.\n");
			response.getWriter().write("in url path: " + request.getParameter("path") + "\n");
			response.getWriter().write("real path: " +
				context.getRealPath(request.getParameter("path")) + "\n");
			response.getWriter().write("root path: " + rootPath + "\n");
			return;
		}
//		if(!Objects.isNull("/fileUpload/" + context.getRealPath(request.getParameter("dest"))))
//		{
//			if(!context.getRealPath(request.getParameter("dest")).contains(rootPath))
//			{
//				response.getWriter().write("Wrong Directory access.\n");
//				response.getWriter().write(context.getRealPath(request.getParameter("path")) + "\n");
//				response.getWriter().write(rootPath + "\n");
//				return;
//			}
//		}
		//�Է°� �˻� ��

		if(request.getParameter("method").equals("rename"))
		{
			try {
				String org_path = context.getRealPath(rootPath_in_url + request.getParameter("path"));
				String new_path = "";
				StringTokenizer st = new StringTokenizer(rootPath_in_url + request.getParameter("path"), "/");
				while (st.hasMoreTokens()) {
					String temp3 = st.nextToken();
					if(st.hasMoreTokens())
						new_path += "/" + temp3;
				}
				new_path = context.getRealPath(new_path + request.getParameter("dest"));

//				response.getWriter().write(org_path + "\n");
//				response.getWriter().write(new_path + "\n");

				File orgFile = new File(org_path);
				File newFile = new File(new_path);
						
				if(orgFile.exists()) {
					orgFile.renameTo(newFile);
				}
			} catch(Exception e) {
				response.getWriter().write(e + "\n");
			}
		}
		else if(request.getParameter("method").equals("delete"))
		{
			File I = new File(context.getRealPath(rootPath_in_url + request.getParameter("path")));
			if(I.isDirectory())
				deleteDirectory(I);
			else
				I.delete();
		}
		else if(request.getParameter("method").equals("cut"))
		{
			String str = "cut:" + request.getParameter("path");
			session.setAttribute("prev_method", str);
		}
		else if(request.getParameter("method").equals("newDirectory"))
		{
			File CreateDir = new File(context.getRealPath(request.getParameter("path")));
			CreateDir.mkdir();
		}
		else if(request.getParameter("method").equals("copy"))
		{
			String str = "copy:" + request.getParameter("path");
			session.setAttribute("prev_method", str);
		}
		else if(request.getParameter("method").equals("paste"))
		{
			if(Objects.isNull(session.getAttribute("prev_method")))
			{
				response.getWriter().write("Not Copied.");
				return;
			}
			else
			{
				String temp1 = (String)session.getAttribute("prev_method");
				String[] temp2 = temp1.split(":");
				String method = temp2[0];
				String prev_path = temp2[1];
				String filename = "";

				StringTokenizer st2 = new StringTokenizer(prev_path, "/");
				while (st2.hasMoreTokens()) {
					filename = st2.nextToken();
				}

				String new_path = context.getRealPath(rootPath_in_url + request.getParameter("path") + "/" + filename);
				String org_path = context.getRealPath(rootPath_in_url + prev_path);

//				response.getWriter().write(org_path + "\n");
//				response.getWriter().write(new_path + "\n");

				if(method.equals("cut"))
				{
					try {
						File orgFile = new File(org_path);
						File newFile = new File(new_path);
								
						if(orgFile.exists()) {
							orgFile.renameTo(newFile);
						}
					} catch(Exception e) {
						response.getWriter().write(e + "\n");
					}
				}
				else if(method.equals("copy"))
				{
					File orgFile = new File(org_path);
					File newFile = new File(new_path);

					if(orgFile.isDirectory())
					{
						if(!newFile.isDirectory())
							newFile.mkdir();
						copyDir(orgFile, newFile);
					}
					else
					{
						copy(orgFile, newFile);
					}
				}
			}
		}
		response.getWriter().write("refresh");
		return;

		//response.getWriter().write((String)session.getAttribute("prev_method"));
	}
}