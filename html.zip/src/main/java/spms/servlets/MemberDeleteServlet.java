package spms.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// ServletContext�� ������ Connection ��ü ���  
@WebServlet("/member/delete")
public class MemberDeleteServlet extends HttpServlet {

	public static boolean deleteDirectory(File path) {
		if(!path.exists()) {
			return false;
		}
		 
		File[] files = path.listFiles();
		for (File file : files) {
			if (file.isDirectory()) {
				deleteDirectory(file);
			} else {
				file.delete();
			}
		}
		 
		return path.delete();
	}

	private static final long serialVersionUID = 1L;

	@Override
	public void doGet(
			HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Connection conn = null;
		Statement stmt = null;

		try {
			ServletContext sc = this.getServletContext();
			ServletContext context = getServletContext();
			conn = (Connection) sc.getAttribute("conn");   
			stmt = conn.createStatement();
			stmt.executeUpdate(
					"DELETE FROM MEMBERS WHERE MNO=" + 
					request.getParameter("no"));

			File I = new File(sc.getRealPath("/fileUpload/" + request.getParameter("id")));
			if(I.isDirectory())
				deleteDirectory(I);
			else
				I.delete();

			response.sendRedirect("list");
			
		} catch (Exception e) {
			throw new ServletException(e);
			
		} finally {
			try {if (stmt != null) stmt.close();} catch(Exception e) {}
			//try {if (conn != null) conn.close();} catch(Exception e) {}
		}

	}
}
