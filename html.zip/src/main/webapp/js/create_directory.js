$(document).ready(function() {
	var path = "";

	$('#create_directory_button').click(function () {
		var create_dir = path + "/" + $("#new_directory_name_text").val();
		$.ajax({
			url: file_control_url,
			type: "POST",
			dataType: "text",
			data: {
				"method": "newDirectory",
				"path": create_dir
			},
			success : function(data){
				if(data == "refresh")
					setTimeout(function(){
						location.reload();
					}, 1500);
				else
					console.log(data);
			},
			error : function(data){
				console.log("���� : " + data.responseText);
			},
			complete : function(){
				console.log("ajax finish");
			}
		});
	});

	$('#createDirectoryModal').on('show.bs.modal', function (event) {
		var button = $(event.relatedTarget); // Button that triggered the modal
		path = button.data('current-directory'); // Extract info from data-* attributes
		// If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
		// Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
		var modal = $(this);
	});

	$('#createDirectoryModal').on('hide.bs.modal', function (event) {
		path = "";
		$("#new_directory_name_text").val("");
	});
});