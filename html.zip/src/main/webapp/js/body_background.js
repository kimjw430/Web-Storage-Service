$(document).ready(function(){
	$("body").css("background-image", "url('/wss/img/background.jpg')"); 
	$("body").css("background-repeat", "no-repeat");
	$("body").css("background-attachment", " fixed");
	$("body").css("-webkit-background-size", "cover");
	$("body").css("-moz-background-size", "cover");
	$("body").css("-o-background-size", "cover");
	$("body").css("background-size", "cover");
});