var rename_modal = $("#renameFileModal");
var path = "";
var file_control_url = "";
if(window.location.port == "" || window.location.port == 0)
	file_control_url = "http://" + window.location.hostname +
		"/wss/file_control";
else
	file_control_url = "http://" + window.location.hostname + ":" +
		window.location.port + "/wss/file_control";



$('#directory_info').contextMenu({
	selector: 'a', 
	callback: function(key, options) {
		var temp = $(this).attr("href").split("path=");
		path = temp[1];

		var m = "clicked: " + key + " on " + path;
		window.console && console.log(m);

		
		if(key == "rename")
		{
			rename_modal.modal();
		}
		else
		{
			$.ajax({
				url: file_control_url,
				type: "POST",
				dataType: "text",
				data: {
					"method": key,
					"path": path
				},
				success : function(data){
					if(data == "refresh")
						setTimeout(function(){
							location.reload();
						}, 1500);
					else
						console.log(data);
				},
				error : function(data){
					console.log("���� : " + data.responseText);
				},
				complete : function(){
				}
			});
		}
	},
	items: {
		"rename": {name: "Rename", icon: "edit"},
		"cut": {name: "Cut", icon: "cut"},
		"copy": {name: "Copy", icon: "copy"},
		"paste": {name: "Paste", icon: "paste"},
		"delete": {name: "Delete", icon: "delete"},
		"sep1": "---------",
		"quit": {name: "Quit", icon: "quit"}
	}
});

$('#renameFileModal').on('show.bs.modal', function (event) {
	var modal = $(this);
	modal.find('.modal-body input').val("");
});
$('#renameFileModal').on('hide.bs.modal', function (event) {
	var modal = $(this);
	modal.find('.modal-body input').val("");
});
$('#rename_modal_button').click(function () {
	var rename_path = "/" + $("#rename_text").val();
	console.log("test");
	$.ajax({
		url: file_control_url,
		type: "POST",
		dataType: "text",
		data: {
			"method": "rename",
			"path": path,
			"dest": rename_path
		},
		success : function(data){
			if(data == "refresh")
				setTimeout(function(){
					location.reload();
				}, 1500);
			else
				console.log(data);
		},
		error : function(data){
			console.log("���� : " + data.responseText);
		},
		complete : function(){
			console.log("ajax finish");
		}
	});
});